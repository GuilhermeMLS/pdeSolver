var searchData=
[
  ['calculate_5findex_36',['calculate_index',['../pdelib_8c.html#aa328e4b6aaa5d1001ce42330fdc44bf3',1,'calculate_index(int i, int j, int n):&#160;pdelib.c'],['../pdelib_8h.html#aa328e4b6aaa5d1001ce42330fdc44bf3',1,'calculate_index(int i, int j, int n):&#160;pdelib.c']]],
  ['calculate_5fresidues_37',['calculate_residues',['../pdelib_8c.html#a406b14fb42830099a6fed19ca377ef9f',1,'calculate_residues(t_LS5Diag *SL, t_float *u):&#160;pdelib.c'],['../pdelib_8h.html#a406b14fb42830099a6fed19ca377ef9f',1,'calculate_residues(t_LS5Diag *SL, t_float *u):&#160;pdelib.c']]]
];
