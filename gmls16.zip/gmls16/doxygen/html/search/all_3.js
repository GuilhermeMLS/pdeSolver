var searchData=
[
  ['gaussseidel_9',['gaussSeidel',['../pdelib_8c.html#a182aa391a11b5e744e7e64a3536dc7da',1,'gaussSeidel(t_LS5Diag **SL, t_float **u):&#160;pdelib.c'],['../pdelib_8h.html#a182aa391a11b5e744e7e64a3536dc7da',1,'gaussSeidel(t_LS5Diag **SL, t_float **u):&#160;pdelib.c']]],
  ['generateoutputfile_10',['generateOutputFile',['../pdelib_8c.html#ab7ecd5b0ce4b9bc177fcf9055a5862d4',1,'generateOutputFile(unsigned int iterations, char *output_file, double gauss_seidel_total_time, t_float *residues, t_LS5Diag *SL, t_float *u):&#160;pdelib.c'],['../pdelib_8h.html#a7f5ee0f1ea5fe58d057b0dbcf641fcb5',1,'generateOutputFile(unsigned int num_iter, char *arq_saida, double tempo_total_GaussSiedel, t_float *residuo_iter, t_LS5Diag *sist, t_float *solucao):&#160;pdelib.c']]],
  ['get_5foptions_11',['get_options',['../pdelib_8c.html#afa692d565f8611db3356748fbf02fb12',1,'get_options(int argc, char **argv, int *nx, int *ny, int *max_iterations, char **output_file):&#160;pdelib.c'],['../pdelib_8h.html#afa692d565f8611db3356748fbf02fb12',1,'get_options(int argc, char **argv, int *nx, int *ny, int *max_iterations, char **output_file):&#160;pdelib.c']]]
];
