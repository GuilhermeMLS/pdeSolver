var searchData=
[
  ['allocate_5fand_5fstart_5flinear_5fsystem_34',['allocate_and_start_linear_system',['../pdelib_8c.html#a1ea065fb53eade4fed1f6fa623483095',1,'allocate_and_start_linear_system(t_LS5Diag **SL, int nx, int ny):&#160;pdelib.c'],['../pdelib_8h.html#a1ea065fb53eade4fed1f6fa623483095',1,'allocate_and_start_linear_system(t_LS5Diag **SL, int nx, int ny):&#160;pdelib.c']]],
  ['allocate_5fand_5fstart_5fsolution_35',['allocate_and_start_solution',['../pdelib_8c.html#a98bd6d25a01645f62444e019353324e9',1,'allocate_and_start_solution(t_float **u, t_LS5Diag *SL):&#160;pdelib.c'],['../pdelib_8h.html#a98bd6d25a01645f62444e019353324e9',1,'allocate_and_start_solution(t_float **u, t_LS5Diag *SL):&#160;pdelib.c']]]
];
