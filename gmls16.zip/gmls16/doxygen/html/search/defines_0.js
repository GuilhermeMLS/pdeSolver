var searchData=
[
  ['maximum_5ferror_55',['MAXIMUM_ERROR',['../pdelib_8h.html#af7185f948678c6ae69bbd7c075a46ccc',1,'pdelib.h']]]
];
