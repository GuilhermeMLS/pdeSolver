var searchData=
[
  ['a_20program_20to_20find_20an_20approximate_20solution_20to_20a_20partial_20differential_20equation_20using_20the_20gauss_2dseidel_20iterative_20method_2e_57',['A program to find an approximate solution to a Partial Differential Equation using the Gauss-Seidel iterative method.',['../index.html',1,'']]]
];
