var indexSectionsWithContent =
{
  0: "abcgmnprstu",
  1: "t",
  2: "mpr",
  3: "acgmst",
  4: "abmnu",
  5: "t",
  6: "mp",
  7: "ap"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

