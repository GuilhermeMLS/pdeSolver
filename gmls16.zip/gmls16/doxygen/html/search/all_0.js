var searchData=
[
  ['allocate_5fand_5fstart_5flinear_5fsystem_0',['allocate_and_start_linear_system',['../pdelib_8c.html#a1ea065fb53eade4fed1f6fa623483095',1,'allocate_and_start_linear_system(t_LS5Diag **SL, int nx, int ny):&#160;pdelib.c'],['../pdelib_8h.html#a1ea065fb53eade4fed1f6fa623483095',1,'allocate_and_start_linear_system(t_LS5Diag **SL, int nx, int ny):&#160;pdelib.c']]],
  ['allocate_5fand_5fstart_5fsolution_1',['allocate_and_start_solution',['../pdelib_8c.html#a98bd6d25a01645f62444e019353324e9',1,'allocate_and_start_solution(t_float **u, t_LS5Diag *SL):&#160;pdelib.c'],['../pdelib_8h.html#a98bd6d25a01645f62444e019353324e9',1,'allocate_and_start_solution(t_float **u, t_LS5Diag *SL):&#160;pdelib.c']]],
  ['away_5fbottom_5fdiagonal_2',['away_bottom_diagonal',['../structt___l_s5_diag.html#a2155f9e524d5efaf7da9e4dd193f973a',1,'t_LS5Diag']]],
  ['away_5fupper_5fdiagonal_3',['away_upper_diagonal',['../structt___l_s5_diag.html#a52b2e75f116bf535df5710a6d0ee9f29',1,'t_LS5Diag']]],
  ['a_20program_20to_20find_20an_20approximate_20solution_20to_20a_20partial_20differential_20equation_20using_20the_20gauss_2dseidel_20iterative_20method_2e_4',['A program to find an approximate solution to a Partial Differential Equation using the Gauss-Seidel iterative method.',['../index.html',1,'']]]
];
