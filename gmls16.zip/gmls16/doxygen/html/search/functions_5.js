var searchData=
[
  ['timestamp_43',['timestamp',['../pdelib_8c.html#ad1f75d4b6d05731f71dd8fe6ee54bfeb',1,'timestamp(void):&#160;pdelib.c'],['../pdelib_8h.html#ad1f75d4b6d05731f71dd8fe6ee54bfeb',1,'timestamp(void):&#160;pdelib.c']]]
];
