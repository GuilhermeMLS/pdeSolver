var searchData=
[
  ['show_5fhelp_24',['show_help',['../pdelib_8c.html#a83d801e13cc875bfa34e9cf132b9883f',1,'show_help(char *name):&#160;pdelib.c'],['../pdelib_8h.html#a83d801e13cc875bfa34e9cf132b9883f',1,'show_help(char *name):&#160;pdelib.c']]]
];
