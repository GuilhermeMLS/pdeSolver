# Partial Differential Equation Solver
A program to find an approximate solution to a Partial Differential Equation (PDE) using the Gauss-Seidel iterative method to solve the pentadiagonal matrix that represents the Linear System found with the aproximation of the partial derivatives of the equation.
